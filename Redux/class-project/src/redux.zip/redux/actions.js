import { ADD_STAGIRE } from "./actionstype";

export function addstg(stg){
   return{
    type:ADD_STAGIRE,
    playoud:stg
   }
}