export const ADD_STAGIRE = "ADD_STAGIRE";
