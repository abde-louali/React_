import { ADD_STAGIRE } from "./actionstype"

const initialstate = {
     stagaire:[
        {
            num:'',
            name:'',
            filier:'',
            notes:[
                
            ]
        }
     ]
}

const appreducer = (state = initialstate,action)=>{
    switch(action.type){
        case ADD_STAGIRE:return{
            ...state,stagaire:[...state.stagaire,action.playoud]
        }
        default :return state
    }
}
export default appreducer